<?php
/**
 * Plugin Name: Browser-POP-up
 * Description: Creating customized pop-up
 * Version: 1.0
 * Author: Team Saviour
 */

function enqueue_script(){
    wp_enqueue_script('pop_js', plugins_url('/js/pop.js', __FILE__), array('jquery'), '', true);
    wp_localize_script( 'pop_js', 'postData',
				array( 
					'ajaxurl' => admin_url( 'admin-ajax.php' ),
				)
			);
    wp_enqueue_style('style_css',plugins_url('/css/style.css', __FILE__));
}
add_action( 'wp_enqueue_scripts', 'enqueue_script' );



function pop_up_maker(){
    ob_start();
    ?>
    <a href="#popup1" id="triggerButton" type="hidden"></a>

    <div id="popup1" class="overlay">
        <div class="popup">
            <p>How can SAVIOUR help you ? <i class='fas fa-map-marked-alt' style='font-size:24px'></i></p>
            <hr style="color:lightgray;">
            <a class="close" href="#">&times;</a>
            <div class="content">
            <p>Nature of your emergency :</p> 
                    <div style="display:inline-block;margin-bottom:20px;"><button class="button-17" value="fire" onclick="getButtonVal(this,1)">Fire</button> <button class="button-17" value="medical" onclick="getButtonVal(this,1)">Medical</button> <button class="button-17" value="accident" onclick="getButtonVal(this,1)">Accident</button>  <button class="button-17" value="threat" onclick="getButtonVal(this,1)">Threat</button> </div>
                    <div style="display:inline-block"><button class="button-17" value="robbery" onclick="getButtonVal(this,1)">Robbery</button> <button class="button-17" value="information" onclick="getButtonVal(this,1)">Information</button> </div>
            </div>
        </div>
    </div>

      <?php
      return ob_get_clean();
}
add_shortcode('pop_up_maker','pop_up_maker');

function get_location_shortcode(){

    ob_start();
    
    $get_id = get_current_user_id();
    
    if($get_id != '0'){?>
    	<button id = "req_button">REQUEST HELP</button>
    <?php
    }
    return ob_get_clean();
}
add_shortcode('live_location','get_location_shortcode');


function sendPopUpInfo(){

    global $wpdb;

    $data = $_POST['data'];
    $user_id = get_current_user_id();
        
    $table_name = $wpdb->prefix . 'user_location';
    $sql = $wpdb->insert(
                $table_name,
                [
                    'latitude' => sanitize_text_field($data['lat']),
                    'location_address' => sanitize_text_field($data['longAddress']),
                    'current_user_id' => $user_id,
                    'longitude' => sanitize_text_field($data['lon']),
                    'location_address_array' => json_encode($data['completeAddress']),
                    'help_info' => json_encode($data['helpInfo'])
                ]
            );
    wp_send_json($data);
}
add_action('wp_ajax_sendData_action', 'sendPopUpInfo');
add_action('wp_ajax_nopriv_sendData_action', 'sendPopUpInfo');

