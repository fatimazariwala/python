console.log('Pop..... SAVIOUR.............');

var triggerButton=document.getElementById('triggerButton');
mainDiv = document.getElementById('popup1');
var nature = {};
var reqButton=document.getElementById('req_button');

document.addEventListener('DOMContentLoaded', function() {
    triggerButton.click();
})

function create_pop_up1(num){
    //mainDiv = document.getElementById('popup1');
    data_for_div = `<div class="popup">
    <p>Just a few more steps.... <i class='fas fa-walking' style='font-size:24px'></i></p>
    <hr style="color:lightgray;">
    <div class="content">
    <p>Are you at the Location of Emergency ?</p> 
            <div style="display:inline-block;margin-bottom:20px;"><button class="button-17" value="yes" onclick="getButtonVal(this,2)">Yes</button> <button class="button-17" id="medical" value="no" onclick="getButtonVal(this,2)">No</button> </div>
    </div>
</div>` ;
    mainDiv.innerHTML = data_for_div;
}

function create_pop_up2(num){
    data_for_div = `<div class="popup">
    <p>Just a few more steps.... <i class='fas fa-walking' style='font-size:24px'></i></p>
    <hr style="color:lightgray;">
    <div class="content">
    <p>Is it a life or death situation ?</p> 
            <div style="display:inline-block;margin-bottom:20px;"><button class="button-17" value="yes" onclick="getButtonVal(this,3)">Yes</button> <button class="button-17" id="medical" value="no" onclick="getButtonVal(this,3)">No</button> </div>
    </div>
</div>` ;
    mainDiv.innerHTML = data_for_div;
}

function create_pop_up3(num){
    data_for_div = `<div class="popup">
    <a class="close" href="#">&#10006;</a>
    <p>Help is on the way..... <i class='fas fa-car-side' style='font-size:24px'></i></p>`
    mainDiv.innerHTML = data_for_div;
    globalThis.helpInfo = {
        "nature of emergency" : nature[1],
        "at location" : nature[2],
        "life or death" : nature[3]
    };
    console.log(globalThis);

    jQuery.ajax({
            type:"post",
            url: postData.ajaxurl,
            data:{
                action:"sendData_action",
                data: globalThis
            },
            complete: function(response){
                console.log("POSTED DATA",response);
            },
            error: function(error){
                console.error("POST AJAX error :", error);
                console.log("Query : ",globalThis);
            }
        });
        
    globalPanlocationButton.click();
}

function getButtonVal(val,num){
    nature[num] = val.value;
    console.log('num : ',num,nature);
    var call_func = "create_pop_up" + num;
    eval(call_func)(num);
}


reqButton.addEventListener('click',() => {
    triggerButton.click();
    console.log("clicked trigger2..........");
})