console.log('Pop SAVIOUR.............');

var triggerButton=document.getElementById('triggerButton');

document.addEventListener('DOMContentLoaded', function() {
    triggerButton.click();
    console.log("clicked trigger..........");
})

function getButtonVal(val){
    var popUp2=document.getElementById('popup2');
    var nature = val.value;

    globalThis.helpInfo = nature;
    console.log(globalThis,nature);

    jQuery.ajax({
        type:"post",
        url: postData.ajaxurl,
        data:{
            action:"sendData_action",
            data: globalThis
        },
        complete: function(response){
            console.log("POSTED DATA",response);
        },
        error: function(error){
            console.error("POST AJAX error :", error);
            console.log("Query : ",globalThis);
        }
    });
    location.href = "#" + popUp2.id;
}